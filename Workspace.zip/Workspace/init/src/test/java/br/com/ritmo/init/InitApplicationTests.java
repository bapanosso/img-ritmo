package br.com.ritmo.init;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitApplicationTests {

	@Test
	void contextLoads() {
	}

}
