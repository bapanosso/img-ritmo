package br.com.ritmo.init.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.ritimo.init.model.Produto;

@RestController
public class HelloController {

	@GetMapping("/hello")
	public String sayHello() {
		return "Olá mundo! Meu primeiro SpringBoot xD";
	}
	
	@GetMapping("/pagina")
	public String mostrarPagina() {
		return "<html> "
				+ "<body> "
				+ "  <h1> Teste de Pagina </h1>"
				+ "  <hr>"
				+ "  <p> Este eh um exemplo de pagina HTML que no fundo nao vai servir pra nada </p>"
				+ "</body>"
				+ "</html>";
	}
	
	
	@GetMapping("/produto")
	public Produto exibirProduto() {
		Produto p = new Produto(1,"Computador Top de linha", 4000.00, 5);
		return p;
	}

}
