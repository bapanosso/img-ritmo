function enviar() {
    var txtLogin = document.getElementById("txtLogin").value;
    var txtSenha = document.getElementById("txtSenha").value;

    console.log("Voce digitou = " + txtLogin + " / " + txtSenha);

    var msgBody = {
        email: txtLogin,
        racf: txtLogin,
        senha: txtSenha
    };

    var cabecalho = {
        method: "POST",
        body: JSON.stringify(msgBody),
        headers: {
            "content-type": "application/json"
        }

    }

    /* como interpretar a instrução a seguir? Se ela fosse "sequencial", seria algo assim:
       res = fetch("http://localhost:8088/login", cabecalho);
       console.log(res);
    */


    fetch("http://localhost:8088/login", cabecalho).then(res => trataStatus(res));
}


function trataStatus(res) {

    if (res.status == 200) {

        // preciso extrair os dados da resposta
        res.json().then(user => {
            localStorage.setItem("userMod", JSON.stringify(user)); //gravo os dados do usuário no cache
            window.location = "comunidades.html"; // mudo de página
        });
    } else if (res.status == 403) {

        var str403 = `<div class="alert alert-danger" role="alert" style="text-align: center;">
        Senha Inválida!
      </div>`;

        var str404 = `<div class="alert alert-danger" role="alert" style="text-align: center;">
      Usuário não encontrado!
      </div>`;

        var str = `<div class="alert alert-danger" role="alert" style="text-align: center;">
        Erro inesperado. Tente novamente...
      </div>`;

        document.getElementById("msgErro").innerHTML = str403;
    } else if (res.status == 404) {
        document.getElementById("msgErro").innerHTML = str404;
    } else {
        document.getElementById("msgErro").innerHTML = str;

    }

}

function isLoggedIn() {

    var userSTR = localStorage.getItem("userMod");
    if (!userSTR) {
        window.location = "index.html";
        return false;
    }
}