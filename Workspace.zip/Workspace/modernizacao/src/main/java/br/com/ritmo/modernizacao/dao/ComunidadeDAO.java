package br.com.ritmo.modernizacao.dao;

import br.com.ritmo.modernizacao.model.Comunidade;
import org.springframework.data.repository.CrudRepository;

public interface ComunidadeDAO extends CrudRepository<Comunidade, Integer> {
	

}
