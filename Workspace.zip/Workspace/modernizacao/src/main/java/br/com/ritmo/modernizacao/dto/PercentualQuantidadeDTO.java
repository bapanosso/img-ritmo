package br.com.ritmo.modernizacao.dto;

public class PercentualQuantidadeDTO {
	
	public double percentual;
	private long quantidade;
	
	public double getPercentual() {
		return percentual;
	}
	public long getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(long quantidade) {
		this.quantidade = quantidade;
	}
	public void setPercentual(double percentual) {
		this.percentual = percentual;
	}
	

}
