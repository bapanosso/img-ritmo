package br.com.ritmo.modernizacao.dto;

public class QuantidadeOcorrenciasDTO {

	private long qtde;
	
	public QuantidadeOcorrenciasDTO(long qtde) {
		this.qtde = qtde;
	}

	public long getQtde() {
		return qtde;
	}

	public void setQtde(long qtde) {
		this.qtde = qtde;
	}
	
	
}