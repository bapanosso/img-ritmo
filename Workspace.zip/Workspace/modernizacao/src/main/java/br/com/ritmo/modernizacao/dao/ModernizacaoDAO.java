package br.com.ritmo.modernizacao.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import br.com.ritmo.modernizacao.dto.PercentualDTO;
import br.com.ritmo.modernizacao.dto.QuantidadeOcorrenciasDTO;
import br.com.ritmo.modernizacao.model.Comunidade;
import br.com.ritmo.modernizacao.model.Modernizacao;

public interface ModernizacaoDAO extends CrudRepository<Modernizacao,Integer>{
	
	public ArrayList<Modernizacao> findAllByComunidade(Comunidade comunidade);
	
	@Query("select new br.com.ritmo.modernizacao.dto.PercentualDTO(sum(m.percentual))  "
		 + " from Modernizacao m where m.comunidade.id = :id")
	public PercentualDTO buscarPercentualDaComunidade(@Param(value="id") int id);

	
	@Query("select new br.com.ritmo.modernizacao.dto.QuantidadeOcorrenciasDTO(count(numSeq)) "
		+  " from Modernizacao m where m.comunidade.id = :id and"
		+  "       year(m.data) = year(:data) and"
		+  "       month(m.data) = month(:data)")
	public QuantidadeOcorrenciasDTO buscarOcorrencias(@Param(value="id") int id, 
			                                       @Param(value="data") LocalDate data);
}