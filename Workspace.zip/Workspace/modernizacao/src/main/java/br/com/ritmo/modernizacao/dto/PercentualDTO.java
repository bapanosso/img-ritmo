package br.com.ritmo.modernizacao.dto;

public class PercentualDTO {
	private double total;

	
	public PercentualDTO(double total) {
		super();
		this.total = total;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
	
	

}
